import Styles from './styles.scss';

export default Styles;
